##Библеотеки для парсинга

import requests
from bs4 import BeautifulSoup as bs


import json




##Библеотеки аиограма для бота тг
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor

from aiogram.types import ReplyKeyboardRemove, \
    ReplyKeyboardMarkup, KeyboardButton, \
    InlineKeyboardMarkup, InlineKeyboardButton


##Кнопки
best = KeyboardButton('Лучшие фильмы 2023 года!')
anime = KeyboardButton('Топ 100 Аниме')
nazad = KeyboardButton('Главное меню!')
janr = KeyboardButton('Определенный жанр!')

ujasi = KeyboardButton('Ужасы')
comedy = KeyboardButton('Комедия')
detektiv = KeyboardButton('Детектив')
boevik = KeyboardButton('Боевик')
fantasy = KeyboardButton('Фэнтези')
mult = KeyboardButton('Мультики')


greet_kb = ReplyKeyboardMarkup().add(best, anime).add(janr)
janr_kb = ReplyKeyboardMarkup().add(ujasi, comedy).add(detektiv, boevik).add(fantasy, mult).add(nazad)

##Инлайн кнопки
pozhelanie = InlineKeyboardMarkup(inline_keyboard=[
    [InlineKeyboardButton(text='Пожелания', callback_data='pozh'), InlineKeyboardButton(text='Поддержка', callback_data='pod')],
])














btn_start = InlineKeyboardMarkup(row_width=1).add(
    InlineKeyboardButton(text='Начать просмотр фильма!', callback_data='film'))











##Ссылка для парсинга Мультиков
URL_TEMPLATE = "https://www.film.ru/compilation/100-luchshih-amerikanskih-multfilmov"
v = requests.get(URL_TEMPLATE)
print(v.status_code)
g = bs(v.text, "html.parser")
mulist = g.find_all('div', class_='film_list')

##Ссылка для парсинг Фэнтэзи
URL_TEMPLATE = "https://www.film.ru/compilation/luchshie-fantasticheskie-filmy-2022-goda"
l = requests.get(URL_TEMPLATE)
print(l.status_code)
o = bs(l.text, "html.parser")
fantlist = o.find_all('div', class_='film_list')


##Ссылка для парсинга Боевиков
URL_TEMPLATE = "https://www.film.ru/compilation/luchshie-priklyuchencheskie-boeviki"
boy = requests.get(URL_TEMPLATE)
print(boy.status_code)
blv = bs(boy.text, "html.parser")
boylist = blv.find_all('div', class_='film_list')


##Ссылка для парсинга комедии
URL_TEMPLATE = "https://www.film.ru/compilation/luchshie-komedii-2022-goda"
com = requests.get(URL_TEMPLATE)
print(com.status_code)
cmd = bs(com.text, "html.parser")
comlist = cmd.find_all('div', class_='film_list')


##Ссылка для парсинга детектива
URL_TEMPLATE = "https://www.film.ru/compilation/luchshie-komedii-2022-goda"
com = requests.get(URL_TEMPLATE)
print(com.status_code)
cmd = bs(com.text, "html.parser")
comlist = cmd.find_all('div', class_='film_list')


##импорт токена из файла конфиг
from config import TOKEN

bot = Bot(token=TOKEN)  ##Сообщил токен бота из файла конфига
dp = Dispatcher(bot)  ##Диспетчер


##Команда start
@dp.message_handler(commands='start')
async def test_commands(message: types.Message):
    await message.answer(
        'Привет!\nЭтот бот создан для того чтобы просматривать фильмы можно было еще ленивее<3\nНапиши команду /help если у тебя возникли сложности',
        reply_markup=btn_start)


##Команда help
@dp.message_handler(commands='help')
async def test_commands(message: types.Message):
    await message.answer(
        'Привет, как я понимаю у тебя возникли какие-либо сложности.\nВот инструкция по использованию:\nБЛАБЛАБЛАБЛАБЛА\nЕсли у вас возникли другие проблемы, либо вы хотите что-либо посоветовать для развития проекта\nперейдите по данным кнопкам',
        reply_markup=pozhelanie)

##Кнопка Назад
@dp.message_handler(text='Главное меню!')
async def nazad(message: types.Message):
    await message.answer('Главное меню!', reply_markup=greet_kb)


##Кнопка поддержки
@dp.message_handler(text='Поддержка!')
async def podderzka(message: types.Message):
    await message.answer('Если у вас возникли со мной, напишите моим создателям\n@lisov18 @virus_037')


##Определенный жанр
@dp.message_handler(text='Определенный жанр!')
async def janri(message: types.Message):
    await message.answer("Выбери жанр предпочитаемого фильма:)", reply_markup=janr_kb)


##Реакция на нажатие инлайн кнопки ПОДДЕРЖКА
@dp.callback_query_handler(text='pozh')
async def pozh_call(callback: types.callback_query):
    await callback.message.answer("Если у вас появились предложения для развития нашего проекта\nНапишите нам: @lisov18 @virus_037")


##Реакция на нажатие инлайн кнопки с сообщения /start
@dp.callback_query_handler(text='film')
async def www_call(callback: types.callback_query):
    await callback.message.answer("Выбери Категорию фильма!", reply_markup=greet_kb)




##Вывод всех фильмов со страницы лучших фильмов 2023 года списком из инлайн кнопок
##Ссылка для парсинга Лучших фильмов 2023 года

URL_TEMPLATE = "https://www.film.ru/a-z/movies/2023"
a = requests.get(URL_TEMPLATE)
print(a.status_code)
soup = bs(a.text, "html.parser")
listfilm = soup.find_all('div', class_='film_list')


@dp.message_handler(text='Лучшие фильмы 2023 года!')
async def process_start_command(message: types.Message):
    ikb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='', callback_data='films')],
    ])
    for name in listfilm:
        ikb.add(InlineKeyboardButton(text=name.get('title'), callback_data=f'films_{name.get("data-id")}'))

    await message.answer('Фильмы', reply_markup=ikb)



#fiejgfdhiughfeuhgreiuhguirehughreiughruehgurehiugrheiuhreuighuirehiugrehughreughuirehguirehuigrehuigrheuighreughuriehguirehguirehuighreuihguirehuigrehuigrhueghuriehgurehugrehuigreuhi
    list_film = []
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/107.0.0.0 Safari/537.36'
    }
    for i in range(1, 18):
        url = f'https://www.film.ru/a-z/movies/ajax?page={i}&js=true'
        page = requests.get(url, headers=headers)
        soup = bs(page.text, 'html.parser')
        html = json.loads(soup.text)[1]['data']
        soup = bs(html, 'html.parser')
        films = soup.find_all('div', class_='film_list')
        for name in films:
            list_film.append(name.get('title')).get_text(
            )
#bhojfrdnojfejoigrjeoigfheougheuighfeiuwhguifewhgiufewhiuvhrewiyughrewiuyghruiewhgirewhugrehwuighrewiughiruewhguirewhuigrehwuighruiewhuigrewhuigrewhiughruiewhuigrewhuigrehuiwghreiuwhguirewhuigrehwiughriuew

    ##парсинг описания фильмов
    @dp.callback_query_handler(lambda callback: callback.data.startswith('films'))
    async def parsing_desk_film(callback: types.CallbackQuery):
        id = callback.data.split('_')[-1]
        URL_TEMPLATE = 'https://www.film.ru/a-z/movies/2023'
        a = requests.get(URL_TEMPLATE)
        soup = bs(a.text, "html.parser")
        link = soup.find('div', {'data-id': id}).find('a', class_='film_list_link').get('href')
        z = requests.get('https://www.film.ru/' + link)
        zz = bs(z.text, "html.parser")
        nazvanie = zz.find('div', class_='wrapper_movies_text').find('p', class_='').get_text()
        nazvaniekb = zz.find('div', class_='wrapper_movies_top_main_right').find('h1', class_='').get_text()

        ikb8 = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=nazvaniekb, callback_data='btn')],
        ])
        print(nazvanie)
        await callback.message.answer(nazvanie, reply_markup=ikb8)


##Вывод всех Аниме со страницы списком из инлайн кнопок
##Ссылка для парсинга топ 100 Анмие
URL_TEMPLATE = "https://www.film.ru/compilation/100-luchshih-anime-serialov"
b = requests.get(URL_TEMPLATE)
print(b.status_code)
n = bs(b.text, "html.parser")
animelist = n.find_all('div', class_='film_list')


@dp.message_handler(text='Топ 100 Аниме')
async def process_start_command(message: types.Message):
    ikb1 = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='', callback_data='anime')],
    ])
    for name1 in animelist:
        ikb1.add(InlineKeyboardButton(text=name1.get('title'), callback_data=f'anime_{name1.get("data-id")}'))

    await message.answer('Аниме', reply_markup=ikb1)
    ##парсинг описания аниме
    @dp.callback_query_handler(lambda callback: callback.data.startswith('anime'))
    async def parsing_desk_film(callback: types.CallbackQuery):
        id = callback.data.split('_')[-1]
        URL_TEMPLATE = 'https://www.film.ru/compilation/100-luchshih-anime-serialov'
        a = requests.get(URL_TEMPLATE)
        soup = bs(a.text, "html.parser")
        link = soup.find('div', {'data-id': id}).find('a', class_='film_list_link').get('href')
        z = requests.get('https://www.film.ru/' + link)
        zz = bs(z.text, "html.parser")
        nazvanie = zz.find('div', class_='wrapper_movies_text').find('p', class_='').get_text()
        nazvaniekb = zz.find('div', class_='wrapper_movies_top_main_right').find('h1', class_='').get_text()

        ikb9 = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=nazvaniekb, callback_data='btn')],
        ])
        print(nazvanie)
        await callback.message.answer(nazvanie, reply_markup=ikb9)



##Вывод всех Ужасов со страницы списком из инлайн кнопок
##Ссылка для парсинга Ужасов
URL_TEMPLATE = "https://www.film.ru/compilation/luchshie-filmy-uzhasov-vseh-vremen"
c = requests.get(URL_TEMPLATE)
print(c.status_code)
m = bs(c.text, "html.parser")
ulist = m.find_all('div', class_='film_list')


@dp.message_handler(text='Ужасы')
async def process_start_command(message: types.Message):
    ikb2 = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='', callback_data='horror')],
    ])
    for horror in ulist:
        ikb2.add(InlineKeyboardButton(text=horror.get('title'), callback_data=f'horro_{horror.get("data-id")}'))

    await message.answer('Ужасы:', reply_markup=ikb2)

    ##парсинг описания аниме
    @dp.callback_query_handler(lambda callback: callback.data.startswith('horro'))
    async def parsing_desk_film(callback: types.CallbackQuery):
        id = callback.data.split('_')[-1]
        URL_TEMPLATE = 'https://www.film.ru/compilation/luchshie-filmy-uzhasov-vseh-vremen'
        try:
            a = requests.get(URL_TEMPLATE)
            soup = bs(a.text, "html.parser")
            link = soup.find('div', {'data-id': id}).find('a', class_='film_list_link').get('href')
            z = requests.get('https://www.film.ru/' + link)
            zz = bs(z.text, "html.parser")
            nazvanie = zz.find('div', class_='wrapper_movies_text').find('p', class_='').get_text()
            nazvaniekb = zz.find('div', class_='wrapper_movies_top_main_right').find('h1', class_='').get_text()
            ikb10 = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text=nazvaniekb, callback_data='btn')],
            ])
            await callback.message.answer(nazvanie, reply_markup=ikb10)
        except AttributeError:
            a = requests.get(URL_TEMPLATE)
            soup = bs(a.text, "html.parser")
            link = soup.find('div', {'data-id': id}).find('a', class_='film_list_link').get('href')
            z = requests.get('https://www.film.ru/' + link)
            zz = bs(z.text, "html.parser")
            nazvaniekb = zz.find('div', class_='wrapper_movies_top_main_right').find('h1', class_='').get_text()
            ikb10 = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text=nazvaniekb, callback_data='btn')],
            ])
            await callback.message.answer('Название фильма отсуствует', reply_markup=ikb10)
            print('Я ОШИБКА')



##Вывод всех Мультиков со страницы списком из инлайн кнопок
@dp.message_handler(text='Мультики')
async def process_start_command(message: types.Message):
    ikb3 = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='', callback_data='multiki')],
    ])
    for multiki in mulist:
        ikb3.add(InlineKeyboardButton(text=multiki.get('title'), callback_data=f'films_{multiki.get("data-id")}'))

    await message.answer('Мультики:', reply_markup=ikb3)


##Вывод всех фэнтези фильмов со страницы списком из инлайн кнопок
@dp.message_handler(text='Фэнтези')
async def process_start_command(message: types.Message):
    ikb4 = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='', callback_data='fantasy')],
    ])
    for fantasy in fantlist:
        ikb4.add(InlineKeyboardButton(text=fantasy.get('title'), callback_data=f'films_{fantasy.get("data-id")}'))

    await message.answer('Фэнтези:', reply_markup=ikb4)


##Вывод всех Боевиков со страницы списком из инлайн кнопок
@dp.message_handler(text='Боевик')
async def process_start_command(message: types.Message):
    ikb5 = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='', callback_data='boevik')],
    ])
    for boy in boylist:
        ikb5.add(InlineKeyboardButton(text=boy.get('title'), callback_data=f'films_{boy.get("data-id")}'))

    await message.answer('Боевик:', reply_markup=ikb5)


##Вывод всех Комедий со страницы списком из инлайн кнопок
@dp.message_handler(text='Комедия')
async def process_start_command(message: types.Message):

    ikb6 = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='', callback_data='comedy')],
    ])
    for com in comlist:
        ikb6.add(InlineKeyboardButton(text=com.get('title'), callback_data=f'films_{com.get("data-id")}'))

    await message.answer('Комедии:', reply_markup=ikb6)


##Вывод всех Детективов со страницы списком из инлайн кнопок
@dp.message_handler(text='Детектив')
async def process_start_command(message: types.Message):
    ikb7 = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='', callback_data='detecti')],
    ])
    for com in comlist:
        ikb7.add(InlineKeyboardButton(text=com.get('title'), callback_data=f'films_{com.get("id")}'))

    await message.answer('Комедии:', reply_markup=ikb7)











if __name__ == '__main__':
    executor.start_polling(dp)
