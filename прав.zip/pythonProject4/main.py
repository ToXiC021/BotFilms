
import requests
from bs4 import BeautifulSoup as bs ## Библеотека для парсинга
import json #Метод форматирования данных при подгрузке новой страницы

##Использзование библеотеки для создания бота в тг
from aiogram import Bot, types
from aiogram.dispatcher import Dispatcher
from aiogram.utils import executor
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton, InlineKeyboardMarkup, InlineKeyboardButton

##импортируем токен из файла конфиг
from config import TOKEN


bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

##Функцмя
def parsing_url(url):
    page = requests.get(url)
    soup = bs(page.text, "html.parser")
    return soup .find_all('div', class_='film_list')


@dp.message_handler(commands='start')
async def test_commands(message: types.Message):
    btn_start = InlineKeyboardMarkup(row_width=1).add(
        InlineKeyboardButton(text='Начать просмотр фильма!', callback_data='film'))
    msg = '''Привет!
Этот бот создан для того чтобы искать фильмы можно было еще проще
Напиши команду /help если у тебя возникли сложности'''
    await message.answer(text=msg, reply_markup=btn_start)


@dp.message_handler(commands='help')
async def test_commands(message: types.Message):
    msg = '''Привет, у тебя возникли сложности?
Вот инструкция по использованию:
Напиши команду /start, далее перейди по кнопке: Начать просмотр фильма, далее нужную категорию и наслаждайся просмотром
Если у вас возникли другие проблемы либо у вас появились какие-либо пожелания для нашего проекта
перейдите по данным кнопкам:'''
    pozhelanie = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='Предложения', callback_data='pozh'),
         InlineKeyboardButton(text='Поддержка', callback_data='pod')],
    ])
    await message.answer(text=msg, reply_markup=pozhelanie)


@dp.message_handler(text='Главное меню!')
async def nazad(message: types.Message):
    best = KeyboardButton('Лучшие фильмы 2023 года!')
    anime = KeyboardButton('Топ 100 Аниме')
    janr = KeyboardButton('Определенный жанр!')
    greet_kb = ReplyKeyboardMarkup().add(best, anime).add(janr)
    await message.answer('Главное меню!', reply_markup=greet_kb)


@dp.message_handler(text='Поддержка!')
async def podderzka(message: types.Message):
    message = '''Если у вас возникли со мной, напишите моим создателям
@lisov18 @virus_037'''
    await message.answer(text=message)


@dp.message_handler(text='Определенный жанр!')
async def janri(message: types.Message):
    nazad = KeyboardButton('Главное меню!')
    ujasi = KeyboardButton('Ужасы')
    comedy = KeyboardButton('Комедия')
    detektiv = KeyboardButton('Детектив')
    boevik = KeyboardButton('Боевик')
    fantasy = KeyboardButton('Фэнтези')
    mult = KeyboardButton('Мультики')
    janr_kb = ReplyKeyboardMarkup().add(ujasi, comedy).add(detektiv, boevik).add(fantasy, mult).add(nazad)
    await message.answer("Выбери жанр предпочитаемого фильма:)", reply_markup=janr_kb)


@dp.callback_query_handler(text='pozh')
async def pozh_call(callback: types.callback_query):
    await callback.message.answer("Если у вас появились предложения для развития нашего проекта напишите нам\n@lisov18 @virus_037")


@dp.callback_query_handler(text='pod')
async def pozh_call(callback: types.callback_query):
    await callback.message.answer("Если у вас появились сложности с работой бота, свяжитесь со мной\n@lisov18")


@dp.callback_query_handler(text='film')
async def www_call(callback: types.callback_query):
    best = KeyboardButton('Лучшие фильмы 2023 года!')
    anime = KeyboardButton('Топ 100 Аниме')
    janr = KeyboardButton('Определенный жанр!')
    greet_kb = ReplyKeyboardMarkup().add(best, anime).add(janr)
    await callback.message.answer("Выбери Категорию фильма!", reply_markup=greet_kb)


def get_info_films(number_page):
    url = f'https://www.film.ru/a-z/movies/2023/ajax?page={number_page}&js=true'
    page = requests.get(url)
    soup = bs(page.text, 'html.parser')
    html = json.loads(soup.text)[1]['data']
    soup = bs(html, 'html.parser')
    films = soup.find_all('div', class_='film_list')
    return films


@dp.message_handler(text='Лучшие фильмы 2023 года!')
async def process_start_command(message: types.Message):
    ikb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='NEXT', callback_data='next_the_best_films_0')],
    ])
    list_film = get_info_films(0)
    for name in list_film:
        ikb.add(InlineKeyboardButton(text=name.get('title'), callback_data=f'films_0_{name.get("data-id")}'))
    await message.answer('Фильмы', reply_markup=ikb)


@dp.callback_query_handler(lambda callback: callback.data.startswith('next_the_best_films_'))
async def next_the_best_films(callback: types.CallbackQuery):
    page = int(callback.data.split('_')[-1]) + 1
    ikb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='NEXT', callback_data=f'next_the_best_films_{page}')],
        [InlineKeyboardButton(text='BACK', callback_data=f'back_the_best_films_{page}')],
    ])
    list_film = get_info_films(page)
    if len(list_film) > 0:
        for name in list_film:
            ikb.add(InlineKeyboardButton(text=name.get('title'), callback_data=f'films_{page}_{name.get("data-id")}'))
        await callback.message.edit_text('Фильмы', reply_markup=ikb)
    else:
        await callback.answer(text='Это последняя страница')


@dp.callback_query_handler(lambda callback: callback.data.startswith('back_the_best_films_'))
async def next_the_best_films(callback: types.CallbackQuery):
    page = int(callback.data.split('_')[-1]) - 1
    ikb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='NEXT', callback_data=f'next_the_best_films_{page}')],
        [InlineKeyboardButton(text='BACK', callback_data=f'back_the_best_films_{page}')],
    ])
    list_film = get_info_films(page)
    for name in list_film:
        ikb.add(InlineKeyboardButton(text=name.get('title'), callback_data=f'films_{page}_{name.get("data-id")}'))
    await callback.message.edit_text('Фильмы', reply_markup=ikb)


@dp.callback_query_handler(lambda callback: callback.data.startswith('films'))
async def parsing_desk_film(callback: types.CallbackQuery):
    try:
        id = callback.data.split('_')[-1]
        number_page = callback.data.split('_')[-2]
        URL_TEMPLATE = f'https://www.film.ru/a-z/movies/2023/ajax?page={number_page}&js=true'
        page = requests.get(URL_TEMPLATE)
        soup = bs(page.text, 'html.parser')
        html = json.loads(soup.text)[1]['data']
        soup = bs(html, 'html.parser')
        link = soup.find('div', {'data-id': id}).find('a', class_='film_list_link').get('href')
        z = requests.get('https://www.film.ru/' + link)
        zz = bs(z.text, "html.parser")
        nazvanie = zz.find('div', class_='wrapper_movies_text').find('p', class_='').get_text()
        nazvaniekb = zz.find('div', class_='wrapper_movies_top_main_right').find('h1', class_='').get_text()
        photo = zz.find('div', class_='wrapper_movies_top_main_left').find('a', class_='wrapper_block_stack wrapper_movies_poster').get('data-src')
        photo = 'https://www.film.ru' + photo
        ikb8 = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=nazvaniekb, url='https://www.film.ru' + link)],
        ])
        await bot.send_photo(chat_id=callback.from_user.id, photo=photo, caption=nazvanie, reply_markup=ikb8)
    except AttributeError:
        await callback.answer(text='Описания нет(Дальше должны отправляться фото и кнопка на фильм, времени не хватило)')


def get_info_anime(number_page):
    url = f'https://www.film.ru/compilation/100-luchshih-anime-serialov/page/{number_page}/ajax?js=true'
    page = requests.get(url)
    soup = bs(page.text, 'html.parser')
    html = json.loads(soup.text)[1]['data']
    soup = bs(html, 'html.parser')
    anime = soup.find_all('div', class_='film_list')
    return anime


@dp.message_handler(text='Топ 100 Аниме')
async def process_start_command(message: types.Message):
    ikb1 = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='NEXT', callback_data=f'next_anime_0')],
    ])
    animelist = parsing_url('https://www.film.ru/compilation/100-luchshih-anime-serialov')
    for name1 in animelist:
        ikb1.add(InlineKeyboardButton(text=name1.get('title'), callback_data=f'anime_0_{name1.get("data-id")}'))

    await message.answer('Аниме', reply_markup=ikb1)


@dp.callback_query_handler(lambda callback: callback.data.startswith('next_anime_'))
async def next_anime(callback: types.CallbackQuery):
    page = int(callback.data.split('_')[-1]) + 1
    ikb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='NEXT', callback_data=f'next_anime_{page}')],
        [InlineKeyboardButton(text='BACK', callback_data=f'back_anime_{page}')],
    ])
    list_anime = get_info_anime(page)
    if len(list_anime) > 0:
        for name in list_anime:
            ikb.add(InlineKeyboardButton(text=name.get('title'), callback_data=f'anime_{page}_{name.get("data-id")}'))
        await callback.message.edit_text('Анимээ', reply_markup=ikb)
    else:
        await callback.answer(text='Это последняя страница')


@dp.callback_query_handler(lambda callback: callback.data.startswith('back_anime_'))
async def back_anime(callback: types.CallbackQuery):
    page = int(callback.data.split('_')[-1]) - 1
    ikb = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='NEXT', callback_data=f'next_anime_{page}')],
        [InlineKeyboardButton(text='BACK', callback_data=f'back_anime{page}')],
    ])
    list_anime = get_info_anime(page)
    for name in list_anime:
        ikb.add(InlineKeyboardButton(text=name.get('title'), callback_data=f'anime_{page}_{name.get("data-id")}'))
    await callback.message.edit_text('Анимэээ', reply_markup=ikb)


@dp.callback_query_handler(lambda callback: callback.data.startswith('anime'))
async def parsing_desk_film(callback: types.CallbackQuery):
    id = callback.data.split('_')[-1]
    number_page = callback.data.split('_')[-2]
    try:
        URL_TEMPLATE = f'https://www.film.ru/compilation/100-luchshih-anime-serialov/page/{number_page}/ajax?js=true'
        page = requests.get(URL_TEMPLATE)
        soup = bs(page.text, 'html.parser')
        html = json.loads(soup.text)[1]['data']
        soup = bs(html, 'html.parser')
        link = soup.find('div', {'data-id': id}).find('a', class_='film_list_link').get('href')
        z = requests.get('https://www.film.ru/' + link)
        zz = bs(z.text, "html.parser")
        nazvanie = zz.find('div', class_='wrapper_movies_text').find('p', class_='').get_text()
        nazvaniekb = zz.find('div', class_='wrapper_movies_top_main_right').find('h1', class_='').get_text()
        photo = zz.find('div', class_='wrapper_movies_top_main_left').find('a', class_='wrapper_block_stack wrapper_movies_poster').get('data-src')
        photo = 'https://www.film.ru' + photo
        ikb8 = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text=nazvaniekb, url='https://www.film.ru' + link)],
        ])
        await bot.send_photo(chat_id=callback.from_user.id, photo=photo, caption=nazvanie, reply_markup=ikb8)
    except:

        await callback.answer(text='Описания нет(Дальше должны отправляться фото и кнопка на фильм, времени не хватило)')


@dp.message_handler(text='Ужасы')
async def process_start_command(message: types.Message):
    ikb2 = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='', callback_data='horror')],
    ])
    ulist = parsing_url('https://www.film.ru/compilation/luchshie-filmy-uzhasov-vseh-vremen')
    for horror in ulist:
        ikb2.add(InlineKeyboardButton(text=horror.get('title'), callback_data=f'horro_{horror.get("data-id")}'))

    await message.answer('Ужасы:', reply_markup=ikb2)


@dp.callback_query_handler(lambda callback: callback.data.startswith('horro'))
async def parsing_desk_film(callback: types.CallbackQuery):
        id = callback.data.split('_')[-1]
        URL_TEMPLATE = 'https://www.film.ru/compilation/luchshie-filmy-uzhasov-vseh-vremen'
        try:
            a = requests.get(URL_TEMPLATE)
            soup = bs(a.text, "html.parser")
            link = soup.find('div', {'data-id': id}).find('a', class_='film_list_link').get('href')
            z = requests.get('https://www.film.ru/' + link)
            zz = bs(z.text, "html.parser")
            nazvanie = zz.find('div', class_='wrapper_movies_text').find('p', class_='').get_text()
            nazvaniekb = zz.find('div', class_='wrapper_movies_top_main_right').find('h1', class_='').get_text()
            ikb10 = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text=nazvaniekb, callback_data='btn')],
            ])
            await callback.message.answer(nazvanie, reply_markup=ikb10)
        except AttributeError:
            a = requests.get(URL_TEMPLATE)
            soup = bs(a.text, "html.parser")
            link = soup.find('div', {'data-id': id}).find('a', class_='film_list_link').get('href')
            z = requests.get('https://www.film.ru/' + link)
            zz = bs(z.text, "html.parser")
            nazvaniekb = zz.find('div', class_='wrapper_movies_top_main_right').find('h1', class_='').get_text()
            ikb10 = InlineKeyboardMarkup(inline_keyboard=[
                [InlineKeyboardButton(text=nazvaniekb, callback_data='btn')],
            ])
            await callback.message.answer('Название фильма отсуствует', reply_markup=ikb10)
            print('Я ОШИБКА')


async def process_start_command(message: types.Message):
    ikb3 = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='', callback_data='multiki')],
    ])
    mulist = parsing_url('https://www.film.ru/compilation/100-luchshih-amerikanskih-multfilmov')
    for multiki in mulist:
        ikb3.add(InlineKeyboardButton(text=multiki.get('title'), callback_data=f'films_{multiki.get("data-id")}'))

    await message.answer('Мультики:', reply_markup=ikb3)


@dp.message_handler(text='Фэнтези')
async def process_start_command(message: types.Message):
    ikb4 = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='', callback_data='fantasy')],
    ])
    fantlist = parsing_url('https://www.film.ru/compilation/luchshie-fantasticheskie-filmy-2022-goda')
    for fantasy in fantlist:
        ikb4.add(InlineKeyboardButton(text=fantasy.get('title'), callback_data=f'films_{fantasy.get("data-id")}'))

    await message.answer('Фэнтези:', reply_markup=ikb4)


@dp.message_handler(text='Боевик')
async def process_start_command(message: types.Message):
    ikb5 = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='', callback_data='boevik')],
    ])
    boylist = parsing_url('https://www.film.ru/compilation/luchshie-priklyuchencheskie-boeviki')
    for boy in boylist:
        ikb5.add(InlineKeyboardButton(text=boy.get('title'), callback_data=f'films_{boy.get("data-id")}'))

    await message.answer('Боевик:', reply_markup=ikb5)


@dp.message_handler(text='Комедия')
async def process_start_command(message: types.Message):
    ikb6 = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='', callback_data='comedy')],
    ])
    comlist = parsing_url('https://www.film.ru/compilation/luchshie-komedii-2022-goda')
    for com in comlist:
        ikb6.add(InlineKeyboardButton(text=com.get('title'), callback_data=f'films_{com.get("data-id")}'))

    await message.answer('Комедии:', reply_markup=ikb6)


@dp.message_handler(text='Детектив')
async def process_start_command(message: types.Message):
    ikb7 = InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text='', callback_data='detecti')],
    ])
    comlist = parsing_url('https://www.film.ru/compilation/luchshie-komedii-2022-goda')
    for com in comlist:
        ikb7.add(InlineKeyboardButton(text=com.get('title'), callback_data=f'films_{com.get("id")}'))

    await message.answer('Комедии:', reply_markup=ikb7)


@dp.callback_query_handler()
async def a123(callback: types.CallbackQuery):
    print(callback.data)
if __name__ == '__main__':
    executor.start_polling(dp)